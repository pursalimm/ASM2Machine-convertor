﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Convertor
{
    public partial class Asm2Machine : Form
    {
        SqlConnection cnn = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=" + Application.StartupPath + "\\Database.mdf;Integrated Security=True;User Instance=True");
        SqlDataAdapter ada = new SqlDataAdapter();
        SqlCommand cmd = new SqlCommand();
        DataSet ds = new DataSet();
        DataTable table = new DataTable();

        public string str, res, line;
        public string[] linestr;
        public int BASE;
        bool isNum = true;

        public Asm2Machine()
        {
            InitializeComponent();
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public bool IsNumeric(string str)
        {
            foreach (char c in str)
            {
                if (!char.IsDigit(c))
                {
                    isNum = false;
                    break;
                }
            }
            return isNum;
        }

        private void btnopen_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "ASM Code files(*.asm)|*.asm";
            if (op.ShowDialog() == DialogResult.OK)
            {
                str = op.FileName;
                richtxtasm.Text = System.IO.File.ReadAllText(str);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sv = new SaveFileDialog();
            sv.Filter = "Machine Code files(*.BIN)|*.BIN";
            sv.OverwritePrompt = true;
            str = richtxtmach.Text;
            if (sv.ShowDialog() == DialogResult.OK)
                System.IO.File.WriteAllText(sv.FileName, str);
        }

        void GenerateAddress(string str)
        {
            string zero = res;
            res = "";
            for (int i = str.Length; i < 12; i++)
                res += "0";
            if (zero.Length > 12)
                zero = zero.Substring(zero.Length - 12, 12);
            res += zero;
        }

        void DSearchAddress(string str,int row)     //Direct Addressing
        {
            res = "";
            string[] split;
            split = richtxtasm.Lines.ElementAt(row).Split(new char[] { ' ' });
            res = Convert.ToString(int.Parse(split[1]), 2);
            GenerateAddress(res);
        }

        void ISearchAddress(string str)     //InDirect Addressing
        {
            res = "";
            str += ",";
            for (int i = 0; i < richtxtasm.Lines.Length; i++)
            {
                if ((richtxtasm.Lines.ElementAt(i).ToString().IndexOf("DEC") != -1) && (richtxtasm.Lines.ElementAt(i).ToString().IndexOf(str)!=-1))
                {
                    res = Convert.ToString(i, 2);
                    GenerateAddress(res);
                    break;
                }
                if ((richtxtasm.Lines.ElementAt(i).ToString().IndexOf("HEX") != -1) && richtxtasm.Lines.ElementAt(i).ToString().IndexOf(str)!= -1)
                {
                    res = Convert.ToString(i, 16);
                    GenerateAddress(res);
                    break;
                }
            }
        }

        void LineNumber(string str)
        {
            string zero = "";
            for (int i = str.Length; i < 4; i++)
                zero += "0";
            line += zero + str;
        }

        private void btnConv_Click(object sender, EventArgs e)
        {
            string[] split;
            richtxtmach.Text = "";
            for (int i = 0; i < richtxtasm.Lines.Length; i++)
            {
                if (i == 0)
                {
                    richtxtmach.Text = "0000\r\n";
                    continue;
                }
                ds.Reset();
                ada.SelectCommand = cmd;
                cmd.Connection = cnn;
                cmd.CommandText = "select * from conv where ASM like '" + richtxtasm.Lines.ElementAt(i).Substring(0, 3) + "'";
                cnn.Open();
                cmd.ExecuteNonQuery();
                cnn.Close();
                ada.Fill(ds, "conv");
                table = ds.Tables["conv"];
                
                LineNumber(Convert.ToString(i, 2));
                linestr = richtxtasm.Lines.ElementAt(i).ToString().Split(' ');
                if ((richtxtasm.Lines.ElementAt(i).ToString() != "HLT") && (richtxtasm.Lines.ElementAt(i).ToString() != "END"))
                {
                    if (IsNumeric(linestr[1]) == true)
                    {
                        DSearchAddress(linestr[1],i);
                        if (ds.Tables["conv"].Rows.Count != 0)
                        {
                            richtxtmach.AppendText(line + " " + table.Rows[0]["I"].ToString() +
                                table.Rows[0]["Opcode"].ToString() + " " + res + "\r\n");
                        }
                    }
                    else
                    {
                        ISearchAddress(linestr[1]);
                        if (ds.Tables["conv"].Rows.Count != 0)
                        {
                            richtxtmach.AppendText(line + " " + table.Rows[0]["I"].ToString() +
                                table.Rows[0]["Opcode"].ToString() + " " + table.Rows[0]["Address"].ToString() + " " + res + "\r\n");
                        }
                        else
                            richtxtmach.Text += line + " " + res + "\r\n";
                    }
                }
                else if (richtxtasm.Lines.ElementAt(i).ToString().IndexOf("HLT") != -1)
                {
                    if (ds.Tables["conv"].Rows.Count != 0)
                        richtxtmach.AppendText(line + " " + table.Rows[0]["Address"].ToString() + "\r\n");
                    break;
                }
                res = "";
                line = "";
            }
            for (int i = 0; i < richtxtasm.Lines.Length; i++)
            {
                line = "";
                LineNumber(Convert.ToString(i, 2));
                if (richtxtasm.Lines.ElementAt(i).ToString().IndexOf("DEC") != -1)
                {
                    split = richtxtasm.Lines.ElementAt(i).Split(new char[] { ' ' });
                    res = Convert.ToString(int.Parse(split[1]), 2);
                    GenerateAddress(res);
                    richtxtmach.AppendText(line + " " + res + "\r\n");
                    continue;
                }
                if (richtxtasm.Lines.ElementAt(i).ToString().IndexOf("HEX") != -1)
                {
                    split = richtxtasm.Lines.ElementAt(i).Split(new char[] { ' ' });
                    res = Convert.ToString(int.Parse(split[1]), 16);
                    GenerateAddress(res);
                    richtxtmach.AppendText(line + " " + res + "\r\n");
                    continue;
                }
                if (richtxtasm.Lines.ElementAt(i).ToString().IndexOf("END") != -1)
                {
                    richtxtmach.Text += "0000\r\n";
                    continue;
                }
            }
        }
    }
}
