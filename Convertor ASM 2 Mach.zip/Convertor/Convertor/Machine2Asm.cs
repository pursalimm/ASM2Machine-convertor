﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Convertor
{
    public partial class Machine2Asm : Form
    {
        SqlConnection cnn = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=" + Application.StartupPath + "\\Database.mdf;Integrated Security=True;User Instance=True");
        SqlDataAdapter ada = new SqlDataAdapter();
        SqlCommand cmd = new SqlCommand();
        DataSet ds = new DataSet();
        DataTable table = new DataTable();

        static char key='A';
        string linestr;
        string[] str;
        long res;

        public Machine2Asm()
        {
            InitializeComponent();
        }

        private void btnclose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnopen_Click(object sender, EventArgs e)
        {
            string str;
            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Machine Code files(*.BIN)|*.BIN";
            if (op.ShowDialog() == DialogResult.OK)
            {
                str = op.FileName;
                richtxtmach.Text = System.IO.File.ReadAllText(str);
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            string str;
            SaveFileDialog sv = new SaveFileDialog();
            sv.Filter = "ASM Code files(*.asm)|*.asm";
            sv.OverwritePrompt = true;
            str = richtxtasm.Text;
            if (sv.ShowDialog() == DialogResult.OK)
                System.IO.File.WriteAllText(sv.FileName, str);
        }

        private void btnConv_Click(object sender, EventArgs e)
        {
            int i=0;
            char tmp=key;
            richtxtasm.Text = "";
            for (i = 0; i < richtxtmach.Lines.Length; i++)
            {
                if (i == 0)
                {
                    richtxtasm.Text = "ORG 0\r\n";
                    continue;
                }
                linestr = richtxtmach.Lines.ElementAt(i).ToString();
                str = linestr.Split(new char[] { ' ' });
                int len = str.Length;
                ds.Reset();
                ada.SelectCommand = cmd;
                cmd.Connection = cnn;
                if (len == 4)
                {
                    cmd.CommandText = "select * from conv where I=" + str[1].Substring(0,1) + " and Opcode='" + str[1].Substring(1,3) + "' or Address='"+str[3]+"'";
                    cnn.Open();
                    cmd.ExecuteNonQuery();
                    cnn.Close();
                    ada.Fill(ds, "conv");
                    table = ds.Tables["conv"];
                    if (ds.Tables["conv"].Rows.Count != 0)
                    {
                        richtxtasm.AppendText(table.Rows[0]["ASM"].ToString() + " " + key.ToString() + "\r\n");
                    }
                    else
                        richtxtasm.Text += "\r\n";
                }
                else
                {
                    cmd.CommandText = "select * from conv where Address='" + str[1]+"'";
                    cnn.Open();
                    cmd.ExecuteNonQuery();
                    cnn.Close();
                    ada.Fill(ds, "conv");
                    table = ds.Tables["conv"];
                    if (ds.Tables["conv"].Rows.Count != 0)
                    {
                        richtxtasm.AppendText(table.Rows[0]["ASM"].ToString() +"\r\n");
                        if (str[1] == "0111000000000001")
                        {
                            i++;
                            break;
                        }
                        break;
                    }
                    else
                        richtxtasm.Text += "\r\n";
                }
                key++;
            }
            for (int j = i; j <= richtxtmach.Lines.Length; j++)
            {
                if (j == richtxtmach.Lines.Length)
                {
                    richtxtasm.AppendText("END\r\n");
                    break;
                }
                linestr = richtxtmach.Lines.ElementAt(j).ToString();
                str = linestr.Split(new char[] { ' ' });
                if (str[0] == "0000")
                    continue;
                if (str[1].Substring(0, 1) != "1")
                {
                    long res = Convert.ToInt64(str[1], 2);
                    richtxtasm.AppendText(Convert.ToString(tmp) + ",DEC" + " " + res.ToString() + "\r\n");
                }
                else
                {
                    string rev = str[1];
                    string re = "";
                    for (int k = 0; k < str[1].Length; k++)
                    {
                        if (Convert.ToString(rev[k]) == "0")
                            re += "1";
                        else if (Convert.ToString(rev[k]) == "1")
                            re += "0";
                    }
                    long res = Convert.ToInt64(re, 2);
                    richtxtasm.AppendText(Convert.ToString(tmp) + ",DEC" + " " +"-"+ res.ToString() + "\r\n");
                }
                tmp++;
            }

        }
    }
}
