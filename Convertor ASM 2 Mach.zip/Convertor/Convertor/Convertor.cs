﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Convertor
{
    public partial class Convertor : Form
    {
        public Convertor()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnasm_Click(object sender, EventArgs e)
        {
            Asm2Machine asm = new Asm2Machine();
            asm.ShowDialog();
        }

        private void btnmach_Click(object sender, EventArgs e)
        {
            Machine2Asm mach = new Machine2Asm();
            mach.ShowDialog();
        }
    }
}
