﻿namespace Convertor
{
    partial class Convertor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnasm = new System.Windows.Forms.Button();
            this.btnmach = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnasm
            // 
            this.btnasm.BackgroundImage = global::Convertor.Properties.Resources.mobsync;
            this.btnasm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnasm.Location = new System.Drawing.Point(26, 23);
            this.btnasm.Name = "btnasm";
            this.btnasm.Size = new System.Drawing.Size(183, 183);
            this.btnasm.TabIndex = 0;
            this.btnasm.Text = "ASM Code 2 Machine Code";
            this.btnasm.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnasm.UseVisualStyleBackColor = true;
            this.btnasm.Click += new System.EventHandler(this.btnasm_Click);
            // 
            // btnmach
            // 
            this.btnmach.BackgroundImage = global::Convertor.Properties.Resources.mobsync;
            this.btnmach.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnmach.Location = new System.Drawing.Point(240, 23);
            this.btnmach.Name = "btnmach";
            this.btnmach.Size = new System.Drawing.Size(191, 183);
            this.btnmach.TabIndex = 1;
            this.btnmach.Text = "Machine Code 2 ASM Code";
            this.btnmach.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnmach.UseVisualStyleBackColor = true;
            this.btnmach.Click += new System.EventHandler(this.btnmach_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackgroundImage = global::Convertor.Properties.Resources.Error;
            this.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnExit.Location = new System.Drawing.Point(182, 231);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(83, 74);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Convertor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(461, 332);
            this.ControlBox = false;
            this.Controls.Add(this.btnasm);
            this.Controls.Add(this.btnmach);
            this.Controls.Add(this.btnExit);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Convertor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Convertor(Asm2Machine Code, Machine Code2Asm)";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnmach;
        private System.Windows.Forms.Button btnasm;
    }
}

